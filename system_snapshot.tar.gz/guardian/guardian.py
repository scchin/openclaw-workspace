#!/usr/bin/env python3
"""
System Guardian — 自動化監控守護者 (v3.1)
整合：斷路器 (Circuit Breaker) 與 狀態機協同修復。
"""

import json, os, time, subprocess, urllib.request, urllib.error, threading
from datetime import datetime

# ─── 設定 ───────────────────────────────────────────────────────────────────
PROXY_HEALTH_URL = "http://127.0.0.1:18799/health"
SYNC_URL         = "http://127.0.0.1:18790/sync"
SYNC_INTERVAL    = 10
PROXY_LOG_FILE   = os.path.expanduser("~/.openclaw/logs/rate-limit-proxy.log")
GUARDIAN_LOG     = os.path.expanduser("~/.openclaw/logs/system-guardian.log")
STATE_FILE       = os.path.expanduser("~/.openclaw/hooks/google-model-guard/state.json")
RECOVERY_EVENT   = os.path.expanduser("~/.openclaw/guardian/recovery_event.json")
CHECK_INTERVAL   = 30  # 每 30 秒檢查一次

# ─── 日誌 ───────────────────────────────────────────────────────────────────
def log(message: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{ts}] {message}"
    print(entry)
    try:
        os.makedirs(os.path.dirname(GUARDIAN_LOG), exist_ok=True)
        with open(GUARDIAN_LOG, "a") as f:
            f.write(entry + "\n")
    except Exception:
        pass

def record_event(action: str, detail: str):
    try:
        event = {
            "ts": datetime.now().isoformat(),
            "action": action,
            "detail": detail,
            "status": "recovered"
        }
        with open(RECOVERY_EVENT, "w") as f:
            json.dump(event, f, indent=2)
    except Exception:
        pass

def sync_worker():
    """ UI 同步快道：每 10 秒觸發一次 Gateway 同步信號 """
    log("🛰️ UI Sync Worker 已啟動，進入 10s 專屬同步通道...")
    while True:
        try:
            with urllib.request.urlopen(SYNC_URL, timeout=5) as resp:
                if resp.getcode() == 200:
                    pass # 靜默更新
        except Exception:
            # 同步觸發失敗通常不記錄 log 以免刷屏，除非需要調試
            pass
        time.sleep(SYNC_INTERVAL)

# ─── State 管理 ─────────────────────────────────────────────────────────────
def load_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE) as f:
                return json.load(f)
    except Exception:
        pass
    return {"restart_count": 0, "last_restart_ts": 0}

def save_state(state):
    try:
        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)
    except Exception:
        pass

# ─── 修復動作 ─────────────────────────────────────────────────────────────────

def restart_proxy():
    log("🚀 執行 Proxy 重啟...")
    try:
        uid = os.getuid()
        subprocess.run(["launchctl", "kickstart", "-k", f"gui/{uid}/ai.openclaw.rate-limit-proxy"], check=True)
        log("✅ Proxy 重啟指令已發送")
        return True
    except Exception as e:
        log(f"❌ Proxy 重啟失敗: {str(e)}")
        return False

def restart_gateway():
    log("🚀 執行 Gateway 重啟...")
    try:
        subprocess.run(["openclaw", "gateway", "restart"], check=True)
        log("✅ Gateway 重啟指令已發送")
        return True
    except Exception as e:
        log(f"❌ Gateway 重啟失敗: {str(e)}")
        return False

# ─── 監控邏輯 ─────────────────────────────────────────────────────────────────

def check_proxy():
    try:
        with urllib.request.urlopen(PROXY_HEALTH_URL, timeout=5) as resp:
            if resp.getcode() == 200:
                return True
    except Exception:
        pass
    return False

def check_logs_for_errors():
    if not os.path.exists(PROXY_LOG_FILE):
        return False
    try:
        with open(PROXY_LOG_FILE, "r") as f:
            lines = f.readlines()[-20:]
            error_count = 0
            for line in lines:
                if '"action": "429_detected"' in line or '"action": "proxy_error"' in line:
                    error_count += 1
            if error_count >= 5:
                return True
    except Exception:
        pass
    return False

def monitor_loop():
    log("🛡️ System Guardian v3.1 已啟動，開始監控鏈路健康度 (含斷路器機制)...")
    
    while True:
        try:
            state = load_state()
            now = time.time()
            
            proxy_ok = check_proxy()
            logs_critical = check_logs_for_errors()
            
            # ─── 斷路器 (Circuit Breaker) 邏輯 ───────────────────────────────────
            # 檢查是否在 5 分鐘內重啟過於頻繁
            if state.get("last_restart_ts", 0) > 0:
                if now - state["last_restart_ts"] < 300: # 5 分鐘窗口
                    if state.get("restart_count", 0) >= 3:
                        log("🛑 [斷路器觸發] 偵測到頻繁重啟且錯誤持續。進入維護模式，暫停自動重啟 5 分鐘。")
                        # 更新 Proxy 狀態為 maintenance
                        proxy_state = load_state() #- reuse state file? no, a different key
                        # Need to write to the same state file the proxy uses
                        try:
                            with open(STATE_FILE, "r") as f:
                                ps = json.load(f)
                            ps["status"] = "maintenance"
                            with open(STATE_FILE, "w") as f:
                                json.dump(ps, f, indent=2)
                        except Exception: pass
                        
                        time.sleep(300) # 冷卻
                        state["restart_count"] = 0
                        save_state(state)
                        continue

            if not proxy_ok:
                log("⚠️ 偵測到 Proxy 失去響應或崩潰！")
                if restart_proxy():
                    state["restart_count"] = state.get("restart_count", 0) + 1
                    state["last_restart_ts"] = now
                    save_state(state)
                    record_event("RESTART_PROXY", "Proxy health check failed, executed automatic restart.")
                    time.sleep(5)
                else:
                    log("❌ Proxy 重啟失敗，嘗試重啟 Gateway...")
                    restart_gateway()
            
            elif logs_critical:
                log("⚠️ 偵測到日誌中出現大量嚴重錯誤 (429/500)！")
                if restart_proxy():
                    state["restart_count"] = state.get("restart_count", 0) + 1
                    state["last_restart_ts"] = now
                    save_state(state)
                    record_event("RESTART_PROXY_BY_LOGS", "Excessive errors detected in logs, executed preventive restart.")
                else:
                    restart_gateway()
            
        except Exception as e:
            log(f"❌ 監控循環發生異常: {str(e)}")
        
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    # 啟動 UI 同步專屬通道 (Fast-track)
    sync_thread = threading.Thread(target=sync_worker, daemon=True)
    sync_thread.start()
    
    monitor_loop()
