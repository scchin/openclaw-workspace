#!/usr/bin/env python3
"""
OpenClaw Dual-Mode Injection Proxy (HTTP + WebSocket) - v4.7
The "Absolute Purification" Edition.

Fixes:
1. Removed 'aiohttp' dependency.
2. Enhanced WebSocket Bridge.
3. State-Force Injection.
4. Response Hijacking.
5. Request Interception.
6. DOM Erasure.
7. GLOBAL PURIFICATION: Intercepts and cleans LaTeX symbols from BOTH HTML and JSON responses.
"""

import asyncio
import json
import os
import urllib.request
import re
from concurrent.futures import ThreadPoolExecutor

# ─── 配置 ────────────────────────────────────────────────────────────────────
LISTEN_PORT = 18792
TARGET_PORT = 18789
TARGET_HOST = "127.0.0.1"
AUTH_FILE = os.path.expanduser("~/.openclaw/openclaw.json")
REFRESH_ENDPOINT = "http://127.0.0.1:18793/trigger-refresh"

# 物理清洗映射表 (優先處理長符號)
SYMBOL_MAP = {
    "\\\\rightarrow": "→",
    "\\\\downarrow": "↓",
    "\\\\uparrow": "↑",
    "\\\\approx": "≈",
    "\\\\Rightarrow": "導致",
    "\\\\Leftarrow": "由...得出",
    "\\\\Leftrightarrow": "等同於",
    "→": "→",
    "↓": "↓",
    "↑": "↑",
    "≈": "≈",
}

executor = ThreadPoolExecutor(max_workers=5)

JS_TEMPLATE = """
<script>
(function() {{
    const TOKEN = "{token}";
    if (!TOKEN) return;
    
    console.log('%c[OpenClaw-UltraStable] 啟動：執行全量自癒認證劫持...', 'color: #00ffcc; font-size: 16px; font-weight: bold;');
    
    function forceSync() {{
        try {{
            const tokenKeys = ['token', 'gateway_token', 'authToken', 'openclaw_token', 'api_token', 'session_token'];
            const authFlags = ['isAuthorized', 'loggedIn', 'authenticated', 'auth_status', 'is_auth'];
            tokenKeys.forEach(k => {{ localStorage.setItem(k, TOKEN); sessionStorage.setItem(k, TOKEN); }});
            authFlags.forEach(f => {{ localStorage.setItem(f, 'true'); sessionStorage.setItem(f, 'true'); }});
            const currentSettings = JSON.parse(localStorage.getItem('settings') || '{{}}');
            currentSettings.token = TOKEN;
            currentSettings.authorized = true;
            currentSettings.loggedIn = true;
            localStorage.setItem('settings', JSON.stringify(currentSettings));
            document.cookie = `token=${{TOKEN}}; path=/; max-age=31536000`;
        }} catch (e) {{}}
    }}

    const originalGetItem = localStorage.getItem;
    localStorage.getItem = function(key) {{
        const tokenKeys = ['token', 'gateway_token', 'authToken', 'openclaw_token', 'api_token'];
        if (tokenKeys.includes(key)) return TOKEN;
        const authFlags = ['isAuthorized', 'loggedIn', 'authenticated', 'auth_status'];
        if (authFlags.includes(key)) return 'true';
        return originalGetItem.apply(this, arguments);
    }};

    const originalFetch = window.fetch;
    window.fetch = async (...args) => {{
        let [resource, config] = args;
        if (!config) config = {{}};
        if (!config.headers) config.headers = {{}};
        if (typeof config.headers === 'object') config.headers['Authorization'] = `Bearer ${{TOKEN}}`;
        const response = await originalFetch(resource, config);
        if (response.url.includes('/api/') || response.url.includes('/auth')) {{
            const clone = response.clone();
            try {{
                const text = await clone.text();
                if (text.includes("unauthorized") || text.includes("token missing")) {{
                    return new Response(JSON.stringify({{ status: "ok", authorized: true, token: TOKEN, success: true }}), {{ status: 200, headers: {{ 'Content-Type': 'application/json' }} }});
                }}
            }} catch (e) {{}}
        }}
        return response;
    }};

    const originalSend = window.XMLHttpRequest.prototype.send;
    window.XMLHttpRequest.prototype.send = function(body) {{
        this.setRequestHeader('Authorization', `Bearer ${{TOKEN}}`);
        return originalSend.apply(this, [body]);
    }};

    const observer = new MutationObserver(() => {{
        const body = document.body;
        if (!body) return;
        const walkers = document.createTreeWalker(body, NodeFilter.SHOW_TEXT, null, false);
        let node;
        while (node = walkers.nextNode()) {{
            if (node.textContent.includes("token missing") || node.textContent.includes("unauthorized")) {{
                const parent = node.parentElement;
                if (parent) parent.style.display = 'none';
            }}
        }}
    }});
    
    if (document.body) observer.observe(document.body, {{ childList: true, subtree: true }});
    else window.addEventListener('DOMContentLoaded', () => {{
        if (document.body) observer.observe(document.body, {{ childList: true, subtree: true }});
    }});

    forceSync();
    
    function connect() {{
        const ws = new WebSocket('ws://127.0.0.1:18790');
        ws.onmessage = (evt) => {{ if (evt.data === 'FORCE_RELOAD') window.location.reload(true); }};
        ws.onclose = () => setTimeout(connect, 5000);
    }}
    connect();
}})();
</script>
"""

def purify_content(text):
    """物理清洗函數：移除 LaTeX 並轉換為可讀符號"""
    if not text or not isinstance(text, str):
        return text
    # 1. 處理 \text{...}
    text = re.sub(r'\\text\{([^}]*)\}', r'\1', text)
    # 2. 移除 $ 符號
    text = text.replace('$', '')
    # 3. 根據映射表替換 (先長後短)
    sorted_symbols = sorted(SYMBOL_MAP.keys(), key=len, reverse=True)
    for symbol in sorted_symbols:
        text = text.replace(symbol, SYMBOL_MAP[symbol])
    # 4. 移除殘留 LaTeX 指令 \alpha 等
    text = re.sub(r'\\([a-zA-Z]+)', ' ', text)
    # 5. 移除殘留 { }
    text = text.replace('{', '').replace('}', '')
    return text

def purify_json_recursive(data):
    """遞迴清洗 JSON 結構中的所有字串"""
    if isinstance(data, dict):
        return {k: purify_json_recursive(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [purify_json_recursive(item) for item in data]
    elif isinstance(data, str):
        return purify_content(data)
    else:
        return data

def get_gateway_token():
    try:
        with open(AUTH_FILE, "r") as f:
            config = json.load(f)
            return config.get("gateway", {}).get("auth", {}).get("token")
    except Exception:
        return None

def sync_refresh_call():
    try:
        with urllib.request.urlopen(REFRESH_ENDPOINT, timeout=2.0) as resp:
            return resp.status
    except Exception as e:
        return str(e)

async def trigger_refresh():
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(executor, sync_refresh_call)
    print(f"🔄 [SelfHealing] 偵測到錯誤，已觸發全域刷新: {result}")

async def bridge(reader, writer):
    try:
        while True:
            data = await reader.read(8192)
            if not data: break
            writer.write(data)
            await writer.drain()
    except Exception: pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except: pass

async def handle_client(client_reader, client_writer):
    try:
        header_data = await asyncio.wait_for(client_reader.readuntil(b"\r\n\r\n"), timeout=5.0)
    except Exception:
        client_writer.close()
        return

    header_text = header_data.decode('utf-8', errors='ignore')
    lines = header_text.split("\r\n")
    request_line = lines[0]
    headers = lines[1:]
    is_websocket = any("upgrade: websocket" in line.lower() for line in headers)
    
    try:
        server_reader, server_writer = await asyncio.open_connection(TARGET_HOST, TARGET_PORT)
    except Exception as e:
        client_writer.write(f"HTTP/1.1 502 Bad Gateway\r\n\r\nProxy Error: {e}".encode())
        await client_writer.drain()
        client_writer.close()
        return

    token = get_gateway_token()
    clean_headers = []
    for line in headers:
        if not line: continue
        lline = line.lower()
        if lline.startswith("authorization:") or lline.startswith("accept-encoding:"): continue
        clean_headers.append(line)
    
    if token:
        clean_headers.append(f"Authorization: Bearer {token}")

    final_request = request_line + "\r\n" + "\r\n".join(clean_headers) + "\r\n\r\n"
    server_writer.write(final_request.encode())
    await server_writer.drain()

    if is_websocket:
        await asyncio.gather(bridge(client_reader, server_writer), bridge(server_reader, client_writer))
    else:
        if "POST" in request_line or "PUT" in request_line:
            content_length = 0
            for line in headers:
                if line.lower().startswith("content-length:"):
                    try: content_length = int(line.split(":")[1].strip())
                    except: pass
            if content_length > 0:
                try:
                    body = await asyncio.wait_for(client_reader.readexactly(content_length), timeout=2.0)
                    server_writer.write(body)
                    await server_writer.drain()
                except: pass

        try:
            resp_header_data = await asyncio.wait_for(server_reader.readuntil(b"\r\n\r\n"), timeout=5.0)
            resp_headers_text = resp_header_data.decode('utf-8', errors='ignore')
            
            if "429 Too Many Requests" in resp_headers_text or "500 Internal Server Error" in resp_headers_text:
                asyncio.create_task(trigger_refresh())
            
            modified_resp_headers = []
            for line in resp_headers_text.split("\r\n"):
                if not line: continue
                lline = line.lower()
                if lline.startswith("content-length:") or lline.startswith("transfer-encoding:"): continue
                if lline.startswith("content-security-policy:"): continue
                modified_resp_headers.append(line)
            
            modified_resp_headers.append("Cache-Control: no-cache, no-store, must-revalidate")
            final_resp_headers = "\r\n".join(modified_resp_headers) + "\r\n\r\n"
            
            is_html = "text/html" in resp_headers_text.lower()
            is_json = "application/json" in resp_headers_text.lower()
            
            body = b""
            try:
                while True:
                    chunk = await asyncio.wait_for(server_reader.read(8192), timeout=1.0)
                    if not chunk: break
                    body += chunk
                    if is_html and b"</body>" in body: break
                    if is_json and body.strip().endswith(b"}"): break
            except asyncio.TimeoutError:
                pass

            if is_html:
                try:
                    decoded_body = body.decode('utf-8', errors='ignore')
                    if "API rate limit reached" in decoded_body or "Internal error" in decoded_body:
                        asyncio.create_task(trigger_refresh())
                    decoded_body = purify_content(decoded_body)
                    js_content = JS_TEMPLATE.format(token=token if token else "")
                    if "<head>" in decoded_body:
                        decoded_body = decoded_body.replace("<head>", f"<head>{js_content}", 1)
                    elif "</body>" in decoded_body:
                        decoded_body = decoded_body.replace("</body>", f"{js_content}</body>")
                    else:
                        decoded_body += js_content
                    body = decoded_body.encode('utf-8')
                except Exception: pass
            elif is_json:
                try:
                    data = json.loads(body.decode('utf-8', errors='ignore'))
                    purified_data = purify_json_recursive(data)
                    body = json.dumps(purified_data, ensure_ascii=False).encode('utf-8')
                except Exception: pass
            
            client_writer.write(final_resp_headers.encode() + body)
            await client_writer.drain()
        except Exception:
            pass
        finally:
            client_writer.close()
            server_writer.close()

async def main():
    server = await asyncio.start_server(handle_client, "127.0.0.1", LISTEN_PORT)
    print(f"🚀 OpenClaw Dual-Mode Proxy v4.7 listening on {LISTEN_PORT}...")
    async with server:
        await server.serve_forever()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt: pass
